// pages/newHouse/newHouse.js
let plugin = requirePlugin('route-plan');
let key = 'HLEBZ-BCOCU-JN6VY-2E6FY-QUZAE-CMF4Z';  //使用在腾讯位置服务申请的key
let referer = 'e经纪';   //调用插件的app的名称
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    grayshow: false,//画廊
    huxingImgShow: false,//户型
    images: [],
    houseInfor: {},
    nearByList: [],
    titleList: ['公交', '地铁', '教育', '医院', '银行', '美食', '购物', '健身'],
    active: 0,
    center: {
      lat: '23.099994',
      lng: '113.324520'
    },
    markers: [{
      iconPath: "/images/ejj1.2/mapIcon.png",
      id: 0,
      latitude: 23.099994,
      longitude: 113.324520,
      width: 14,
      height: 20,
      callout: {
        content: `地点 `,
        display: "ALWAYS",
        padding: "8"
      }
    }],
    current: 1,
  },
  bindSwiperChange(event) {//切换的事件
    let index = 0
    if (index > this.data.images.length) {
      index = this.data.images.length + 1
    } else {
      index = event.detail.current + 1
    }
    this.setData({
      current: index
    })
  },
  showGallery() {
    this.setData({
      grayshow: true
    })
  },
  showProgram(e) {
    wx.navigateTo({
      url: '/pages/pricePlan/pricePlan?plan=' + JSON.stringify(e.currentTarget.dataset.commission)
    })
  },
  //路线规划
  goToSite(options) {
    let { longitude, latitude, title } = options.currentTarget.dataset
    let endPoint = JSON.stringify({  //终点
      'name': title,
      'latitude': latitude,
      'longitude': longitude
    });
    wx.navigateTo({ url: 'plugin://route-plan/route-plan?key=' + key + '&referer=' + referer + '&endPoint=' + endPoint })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options, "9999999999999999999999999999999")
    this.setData({
      login: wx.getStorageSync('login')
    })
    this.getHouseInfor(options.id)
  },
  onShareAppMessage: function () {
    let infor = this.data.houseInfor
    console.log(this.data.houseInfor)
    return {
      title: `【${infor.title}】 ${infor.district} ${infor.reference_average_price}元/㎡ `,
      path: `/pages/newHouse/newHouse?id=` + infor.id,
      imageUrl: infor.cover_image,
      success: function (res) {
        // 转发成功
        // console.log("转发成功:" + JSON.stringify(res));
      },
    }
  },
  getHouseInfor(id) {
    let data = {
      pId: id
    }
    let url = '/applet/broker/housingrec/newhousing/findDevHouseById'
    app.$http.post(url, data).then((res) => {
      this.setData({
        'markers[0].callout.content': res.data.title,
        'center.lat': res.data.latitude,
        'center.lng': res.data.longitude,
      })
      this.setData({
        houseInfor: {
          id:res.data.id,
          title: res.data.title,
          address: res.data.address,
          open_time: res.data.open_time,
          reference_average_price: res.data.reference_average_price,
          max_area: res.data.max_area,
          min_area: res.data.min_area,
          latitude: res.data.latitude,
          longitude: res.data.longitude,
          imageUrls: res.data.imageUrls.map(e => {
            return e.image_url
          }),
          sell_point: res.data.sell_point ? res.data.sell_point.split(',') : '',
          modelList: res.data.modelList
            .map(e => {
              return e.type_room_num;
            })
            .join("/"),
          house_manager_type:
            res.data.house_manager_type == 1
              ? "普通住宅"
              : "" || res.data.house_manager_type == 2
                ? "公寓"
                : "" || res.data.house_manager_type == 3
                  ? "花园式洋房"
                  : "" || res.data.house_manager_type == 4
                    ? "酒店式公寓"
                    : "" || res.data.house_manager_type == 5
                      ? "商住两用"
                      : "" || res.data.house_manager_type == 6
                        ? "别墅"
                        : "",
          models: res.data.models.map(e => {
            return {
              area: e.area,
              id: e.id,
              allImg: [e.model_image, ...e.modelImage.map(e => {
                return e.image_url
              })],
              modelImage: e.modelImage,
              model_image: e.model_image,
              price: e.price,
              type_balcony_num: e.type_balcony_num,
              type_parlor_num: e.type_parlor_num,
              type_room_num: e.type_room_num,
              type_toilet_num: e.type_toilet_num,
            }
          }),
          district: res.data.district,
          extend: res.data.extend,
          onsite_manager_name: res.data.onsite_manager_name,
          onsite_manager_mobile: res.data.onsite_manager_mobile,
          commission: res.data.commission,
          cover_image: res.data.cover_image,
          onsite_manager_image: res.data.onsite_manager_image
        }
      })
      console.log(this.data.houseInfor.models)
      this.nearby_search("公交")
    })
  },
  toExtend(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/estateDetails/estateDetails?extend=' + JSON.stringify(e.currentTarget.dataset.extend) + '&houseModle=' + this.data.houseInfor.modelList
    })
  },  //弹窗时间
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
  callHim(e) {
    let login = wx.getStorageSync('login')
    if (!login) {
      this.setData({
        showPop: true
      })
    } else {
      console.log(e.currentTarget.dataset.mobile)
      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.mobile //仅为示例，并非真实的电话号码
      })
    }
  },
  changeItem(e) {
    console.log()
    this.nearby_search(this.data.titleList[e.detail.name])
  },
  nearby_search(keyWord) {//搜索周边
    var _this = this;
    // 调用接口
    app.$qqmapsdk.search({
      keyword: keyWord,  //搜索关键词
      location: `${_this.data.center.lat},${_this.data.center.lng}`,  //设置周边搜索中心点
      success: function (res) { //搜索成功后的回调
        console.log(res)
        _this.setData({
          nearByList: res.data.map(e => {
            return {
              address: e.address,
              // address:  _this.clearContent(e.address),
              title: _this.clearContent(e.title),
              _distance: e._distance
            }
          })
        })
        console.log(_this.data.nearByList)
        // var mks = []
        // for (var i = 0; i < res.data.length; i++) {
        //   mks.push({ // 获取返回结果，放到mks数组中
        //     title: res.data[i].title,
        //     id: res.data[i].id,
        //     latitude: res.data[i].location.lat,
        //     longitude: res.data[i].location.lng,
        //     iconPath: "/resources/my_marker.png", //图标路径
        //     width: 20,
        //     height: 20
        //   })
        // }
        // _this.setData({ //设置markers属性，将搜索结果显示在地图中
        //   markers: mks
        // })
      },
      fail: function (res) {
        console.log(res);
      },
      complete: function (res) {
        console.log(res);
      }
    });
  },
  clearContent(text) {
    return text.replace(/\[.*?\]/g, "").replace(/ *\([^)]*\) */g, "");;
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  /**
  * 用户点击右上角分享
  */

  showHuxing(e) {
    let src = e.currentTarget.dataset.img;//获取data-src
    console.log(e)
    //图片预览
    wx.previewImage({
      current: e.currentTarget.dataset.cu, // 当前显示图片的http链接
      urls: e.currentTarget.dataset.img // 需要预览的图片http链接列表
    })
    // this.setData({
    //   huxingImgShow: true
    // })
  }
})