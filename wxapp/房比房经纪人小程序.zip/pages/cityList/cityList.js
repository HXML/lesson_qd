
const app = getApp();
import Dialog from '../../vantui/dialog/dialog';
Page({
  data: {
    searchValue: '',
    values: ["北京", "上海"],
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    hidden: true,
    openList: false,
    showList: true,
    isfull: false,
    city: "",
    cityList: [],
    firstLetter: [],
    hotCity: [
      {
        CITY_NAME: "北京市",
        LAT: 39.904987,
        LNG: 116.405289,
        CITY_CODE: "110100"
      },
      {
        CITY_NAME: "上海市",
        LAT: 31.231707,
        LNG: 121.472641,
        CITY_CODE: "310100"
      },
      {
        CITY_NAME: "广州市",
        LAT: 23.125177,
        LNG: 113.28064,
        CITY_CODE: "440100"
      },
      {
        CITY_NAME: "深圳市",
        LAT: 22.547001,
        LNG: 114.085945,
        CITY_CODE: "440300"
      },
      {
        CITY_NAME: "成都市",
        LAT: 30.659462,
        LNG: 104.065735,
        CITY_CODE: "510100"
      },

      {
        CITY_NAME: "杭州市",
        LAT: 30.287458,
        LNG: 120.15358,
        CITY_CODE: "330100"
      },
    ],//中间值

  },
  //当前位置信息
  getNowPosition() {
    // let allowGetPosition = wx.getStorageSync('allowGetPosition');
    // if (allowGetPosition) {
    let _this = this
    console.log(9999)
    wx.getLocation({
      type: 'wgs84',
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        app.$qqmapsdk.reverseGeocoder({
          location: { latitude, longitude },
          success(res) {
            console.log(res.result)
            _this.setData({
              city: res.result.address_component.city
            })
            let nowAdderss = {
              cityCode: res.result.ad_info.city_code,
              latitude: res.result.location.lat,
              longitude: res.result.location.lng,
              city: res.result.address_component.city,
              district: res.result.address_component.district,
              province: res.result.address_component.province,
              street: res.result.address_component.street,
              street_number: res.result.address_component.street_number
            }
            let myAddress = {
              lat: res.result.location.lat,//改变城市之后所需要的 暂存
              lng: res.result.location.lng,//改变城市之后需要的 暂存
            }
            wx.setStorageSync("addressInfor", nowAdderss)
            wx.setStorageSync("myAddress", myAddress)
            wx.setStorageSync("cityName", res.result.address_component.city)
          },
          complete() {
            Dialog.alert({
              title: '提示',
              message: '定位成功'
            }).then(() => {
              // on close
              wx.switchTab({
                url: '/pages/index/index'
              })
            });
          }
        })
      }
    })
    // }else{
    //   console.log(777)
    // }
  },
  searchCity(e) {
    console.log(e)
    this.setData({
      searchValue: e.detail.value,
      openList: true,
      showList: false,
      isfull: true
    })
    console.log(this.data.cityList)
    let newArr = []
    if (this.data.searchValue == "" || this.data.values == []) {
      this.setData({
        openList: false,
        showList: true,
        isfull: false,
        shownavindex: 0,
      })
    } else {
      newArr = this.data.cityList.filter(item => {
        return item.CITY_NAME.match(this.data.searchValue) //判断匹配的搜索
      })
      this.setData({
        values: newArr
      })
      console.log("444", newArr)
    }
  },
  // 点击灰色背景隐藏所有的筛选内容
  hidebg: function (e) {
    this.setData({
      openList: false,
      showList: true,
      isfull: false,
      shownavindex: 0,
    })
  },
  onLoad() {
    let allowGetPosition = wx.getStorageSync('allowGetPosition');

    let add = wx.getStorageSync('addressInfor');
    console.log(add)
    this.setData({
      city: add.city,
      allowGetPosition: allowGetPosition
    })
    let list = [];
    for (let i = 0; i < 26; i++) {
      list[i] = String.fromCharCode(65 + i)
    }
    this.setData({
      list: list,
      listCur: list[0]
    })
    this.getCityList()
  },
  getCityList() {
    let url = "/applet/provincial/findAllCity"
    app.$http.get(url).then((res) => {
      console.log(res)
      this.setData({
        cityList: res.data
      })
    })
  },

  onReady() {
    let that = this;
    wx.createSelectorQuery().select('.indexBar-box').boundingClientRect(function (res) {
      that.setData({
        boxTop: res.top
      })
    }).exec();
    wx.createSelectorQuery().select('.indexes').boundingClientRect(function (res) {
      that.setData({
        barTop: res.top
      })
    }).exec()
  },

  changeCityItem(e) {
    console.log(e.target.dataset)
    let nowAdderss = {
      city: e.target.dataset.name,
      latitude: e.target.dataset.lat,
      longitude: e.target.dataset.lng,
      code: e.target.dataset.code
    }
    wx.setStorageSync("addressInfor", nowAdderss)
    wx.setStorageSync("cityName", e.target.dataset.name)
    wx.switchTab({
      url: "../index/index"
    })
  },
  changeCity(e) {
    console.log(e.target.dataset)
    let nowAdderss = {
      city: e.target.dataset.name,
      latitude: e.target.dataset.lat,
      longitude: e.target.dataset.lng,
      code: e.target.dataset.code
    }

    wx.setStorageSync("addressInfor", nowAdderss)
    wx.setStorageSync("cityName", e.target.dataset.name)
    wx.switchTab({
      url: "../index/index"
    })
  },
  prevent() { },
  //获取prevent文字信息
  getCur(e) {
    this.setData({
      hidden: false,
      listCur: this.data.list[e.target.id],
    })
  },

  setCur(e) {
    this.setData({
      hidden: true,
      listCur: this.data.listCur
    })
  },
  //滑动选择Item
  tMove(e) {
    let y = e.touches[0].clientY,
      offsettop = this.data.boxTop,
      that = this;
    //判断选择区域,只有在选择区才会生效
    if (y > offsettop) {
      let num = parseInt((y - offsettop) / 20);
      this.setData({
        listCur: that.data.list[num]
      })
    };
  },

  //触发全部开始选择
  tStart() {
    this.setData({
      hidden: false
    })
  },

  //触发结束选择
  tEnd() {
    this.setData({
      hidden: true,
      listCurID: this.data.listCur
    })
  },
  indexSelect(e) {
    let that = this;
    let barHeight = this.data.barHeight;
    let list = this.data.list;
    let scrollY = Math.ceil(list.length * e.detail.y / barHeight);
    for (let i = 0; i < list.length; i++) {
      if (scrollY < i + 1) {
        that.setData({
          listCur: list[i],
          movableY: i * 20
        })
        return false
      }
    }
  }
});