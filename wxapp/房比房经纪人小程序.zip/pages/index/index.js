
const app = getApp()
Page({
  data: {
    login: false,
    indexSwiperList: [{
      resource_url: "http://fangbifang.oss-cn-shenzhen.aliyuncs.com/backstage/jDB7fi_1571217373711.jpg"
    }],//swiper
    List: [],//list
    autoplay: true,
    cityName: "",
    showPop: false,//tanchuang
    betterHouse: [],
    sameCity: false,
    showOneButtonDialog: false,
    oneButton: [{ text: '确定' }],
  },
  handleCall() {
    wx.makePhoneCall({
      phoneNumber: '400-0990-958',
    })
  },
  tapDialogButton(e) {
    this.setData({
      showOneButtonDialog: false
    })
  },
  onLoad(options) {
    this.getNowAddress()
    console.log(options.invitationId)
    wx.setStorageSync("invitationId", options.invitationId)//获取邀请者的ID
    this.getBanner()
    this.getBetterHouse()
  },
  onShow() {
    this.setData({
      cityName: wx.getStorageSync("cityName")
    })
  },
  toList(e) {
    console.log(e.currentTarget.dataset.type)
    if (e.currentTarget.dataset.type === "secondHandList") {
      wx.navigateTo({
        url: "/pages/secondHandHouseList/secondHandHouseList"
      })
    }
    if (e.currentTarget.dataset.type === "newHouseList") {
      wx.navigateTo({
        url: "/pages/newHouseList/newHouseList"
      })
    }
    if (e.currentTarget.dataset.type === "myTeamList") {
      wx.navigateTo({
        url: "/pages/recommendList/recommendList"
      })
    }
    if (e.currentTarget.dataset.type === "sellList") {
      wx.navigateTo({
        url: "/pages/sellList/sellList"
      })
    }
  },
  getBanner() {//获取首页的轮播图
    let _this = this
    let url2 = "/adv/listAdvertisingSpace"
    app.$http.get(url2).then(res => {
      console.log(res)
      let item = res.data.find(e => {
        return e.tag == "applet_homepage"
        // return e.tag == "person_house_choiceness"
      })
      console.log(item)
      //根据广告列表查询首页的广告栏
      let data3 = {
        aId: item.id,
        city: "深圳市"
      }
      let ulr3 = "/adv/listAdvertising"
      app.$http.post(ulr3, data3).then(res => {
        console.log('444444444444444', res)
        _this.setData({
          indexSwiperList: res.data.map(e => {
            return {
              ad_name: e.ad_name,
              ad_url: encodeURIComponent(e.ad_url),
              ad_weight: e.ad_weight,
              begin_time: e.begin_time,
              bg_image: e.bg_image,
              end_time: e.end_time,
              resource_url: e.resource_url,
              type: e.type,
            }
          })
        })
      })
    })
  },
  geTel(tel) {
    return tel.substring(0, 1) + "**" + tel.substr(tel.length);
  },
  // ejj1.2
  getNowAddress() {
    let _this = this
    if (wx.getStorageSync("cityName")) {
      wx.getLocation({
        type: 'wgs84',
        success(res) {
          console.log(res)
          const latitude = res.latitude
          const longitude = res.longitude
          app.$qqmapsdk.reverseGeocoder({
            location: { latitude, longitude },
            success(res) {
              // console.log(res.result.address_component.city)
              console.log(res.result.address_component, 'res.result.address_component')
              console.log(res.result.address_component.city, 'res.result.address_component.city')
              let nowCity = res.result.address_component.city
              let nowCityDetail = res.result.address_component
              if (wx.getStorageSync("cityName") == res.result.address_component.city) {//是否是当前城市
                _this.setData({
                  cityName: wx.getStorageSync("cityName")
                })

              } else {
                wx.showModal({
                  confirmColor: '#60DC74',
                  title: '温馨提示',
                  content: `是否切换到当前城市：${nowCity}`,
                  success(res) {
                    if (res.confirm) {
                      console.log('用户点击确定')
                      _this.setData({
                        cityName: nowCity
                      })
                      wx.setStorageSync("cityName", nowCity)
                      wx.setStorageSync("addressInfor", nowCityDetail)
                    } else {
                      _this.setData({
                        cityName: wx.getStorageSync("cityName")
                      })
                    }
                  }
                })
              }
            }
          })
        }
      })
    } else {
      let _this = this
      wx.getLocation({
        type: 'wgs84',
        success(res) {
          console.log(res)
          const latitude = res.latitude
          const longitude = res.longitude
          app.$qqmapsdk.reverseGeocoder({
            location: { latitude, longitude },
            success(res) {
              // console.log(res.result.address_component.city)
              console.log(res.result.address_component, 'res.result.address_component')
              console.log(res.result.address_component.city, 'res.result.address_component.city')
              wx.setStorageSync("cityName", res.result.address_component.city)
              _this.setData({
                cityName: res.result.address_component.city
              })
            }

          })
        }
      })
    }

  },
  toSecondDetail(e) {// 二手房详情页面
    console.log(e)
    wx.navigateTo({
      url: '../secondHandHouse/secondHandHouse'
    })
  },
  //弹窗时间
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
  callHim(e) {
    let login = wx.getStorageSync('login')
    if (!login) {
      this.setData({
        showPop: true
      })
    } else {
      console.log(e.currentTarget.dataset.mobile)
      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.mobile //仅为示例，并非真实的电话号码
      })
    }
  },
  getBetterHouse() {
    let url = "/applet/broker/housingrec/pesonhouse/findPageEPersonHouse"
    let data = {
      pageNumber: 1,
      pageSize: 6,
      type: 3,    //房源类型（1为普通房源，2为优质房源 3速卖宝
      model: "",//户型1-5 直接传数字，不限传"" 5室以上就传5室以上
      price: "",//-
      decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
      province: "",//省级行政区
      city: "",//市级行政区
      // district: "龙华新区",//区
      // street: "观澜街道",//街道
    }
    app.$http.post(url, data).then((res) => {
      console.log(res)
      this.setData({
        betterHouse: res.data.list.map(e => {
          return {
            address: e.address,
            area: e.area,
            city: e.city,
            decorate_status: e.decorate_status,
            district: e.district,
            id: e.id,
            mobile: e.mobile,
            name: e.name,
            position: e.position,
            province: e.province,
            sell_house_price: e.sell_house_price,
            street: e.street,
            type_balcony_num: e.type_balcony_num,//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
            type_parlor_num: e.type_parlor_num,//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
            type_room_num: e.type_room_num,//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
            type_toilet_num: e.type_toilet_num,//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
          }
        })
      })
    })
  },
  toHouseDetail(e) {
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: "/pages/secondHandHouse/secondHandHouse?id=" + e.currentTarget.dataset.id
    })
  },
  onShareAppMessage(options) {

  },
  onPullDownRefresh() {//刷新
    wx.showToast({
      title: '加载中....',
      icon: 'loading'
    })
    let that = this
    //模拟加载
    setTimeout(function () {
      //点击刷新
      that.setData({
        'sendData.pageNumber': 1,
        ScrollTop: 0
      })
      // console.log(that.data.title)
      // that.data.TabCur == 1 ? that.getList(2) : that.getList(1)
      that.getBetterHouse()
      wx.hideLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
})
