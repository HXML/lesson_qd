// pages/phoneLogin/phoneLogin.js
import Toast from '../../vantui/toast/toast';
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    phone: '',
    checked: true,
    getCodeFont: "获取验证码",
    time: 60,
    disabled: false,//是否禁用
    result: false,//是否是正确的手机号
    scretMsg: '',
    code: ''
  },
  changeChecked() {
    this.setData({
      checked: !this.data.checked
    })
  },
  onCodeChange(e) {
    this.setData({
      code: e.detail
    })
  },
  onChange(e) {
    this.setData({
      phone: e.detail
    })
    let reg = /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/
    let result = reg.test(e.detail)
    this.setData({
      result: result
    })
  },
  getCode(e) {
    let phone = this.data.phone
    //判断手机号是否存在
    let reg = /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/
    let result = reg.test(phone)
    //先判断输入的东西是不是手机号 在做判断
    if (result) {
      this.setData({
        disabled: true
      })
      let url = "/applet/broker/getCodeForLogin"
      let data = {
        mobile: this.data.phone
      }
      console.log(e)
      app.$http.post(url, data).then((result) => {
        let seconds = 60;
        let timer = setInterval(() => {
          seconds--
          if (seconds > 0) {
            this.setData({
              getCodeFont: `(${seconds})重新获取`
            })
            this.setData({
              disabled: true
            })
          } else {
            clearInterval(timer)
            this.setData({
              getCodeFont: `重新获取`
            })
            this.setData({
              disabled: false
            })
          }
        }, 1000)
        console.log("已发送")
      }).catch((err) => {
        console.log("发送失败")
      });
    }
    else {
      Toast.fail('请输入正确的手机号');
    }
  },
  codeLogin() {
    let data = {
      mobile: this.data.phone,
      captcha: this.data.code,
      encryptedData: this.data.scretMsg.encryptedData,
      iv: this.data.scretMsg.iv,
      code: this.data.code
    }
    let url = "/applet/broker/codeLogin"
    app.$http.post(url, data).then(res => {
      console.log(res)
      if (res.msg == "验证码错误") {
        Toast.fail('验证码错误');
      } else {
        wx.setStorageSync("token", res.data.token)
        wx.setStorageSync("login", true)
        wx.setStorageSync("brokerRegionInfo", res.data.brokerRegionInfo)
        wx.switchTab({
          url: '../index/index'
        })
      }
    })
  },
  onLoad(e) {//获取登录的东西
    console.log(e)
    let data = wx.getStorageSync('scretMsg')//登录凭证
    console.log(data)
    this.setData({
      scretMsg: data,
      code: e.code
    })
  },
})