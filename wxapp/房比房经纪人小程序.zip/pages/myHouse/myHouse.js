// pages/myHouse/myHouse.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statusList: ['全部', '审核中', "已发布", '已拒绝', "已下架"],
    activeName: "全部",
    sendData: {
      status: "",
      pageNumber: 1,
      pageSize: 5
    },
    houseList: [],
    msg: "加载中...",
    //过渡的TYPE
    preStuta: "",
    isRelease: false,
  },

  ChangeType(e) {
    console.log(e.currentTarget.dataset.type)
    this.setData({
      activeName: e.currentTarget.dataset.type,
      preStuta: e.currentTarget.dataset.index == 0 ? '' : e.currentTarget.dataset.index
    })
  },
  cancel() {
    this.selectComponent('#item').toggle();
  },
  confirm() {
    this.selectComponent('#item').toggle();
    this.setData({
      'sendData.pageNumber': 1,
      'sendData.status': this.data.preStuta,
      msg: "加载中..."
    })
    wx.pageScrollTo({
      scrollTop: 0
    })
    this.getList()
  },
  onLoad() {
    this.getList()
  },
  getList() {
    let url = "/applet/broker/mymodule/house/getMyHouse"
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      if (res.data.list > 0) {
        this.setData({
          isRelease: true
        })
      }
      this.setData({
        houseList: res.data.list.map(e => {
          return {
            address: e.address,
            area: e.area,
            check_status: e.check_status,
            city: e.city,
            cover_image: e.cover_image,
            decorate_status: e.decorate_status,
            district: e.district,
            house_no: e.house_no,
            id: e.id,
            position: e.position,
            province: e.province,
            sell_house_price: e.sell_house_price,
            street: e.street,
            type: e.type,
            type_balcony_num: e.type_balcony_num,
            type_parlor_num: e.type_parlor_num,
            type_room_num: e.type_room_num,
            type_toilet_num: e.type_toilet_num,
          }
        })
      })
    })
  },
  getMoreList() {
    this.setData({
      'sendData.pageNumber': this.data.sendData.pageNumber + 1
    })
    let url = "/applet/broker/mymodule/house/getMyHouse"
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      console.log(this.data.houseList.length)
      if (res.data.totalRow > this.data.houseList.length) {
        this.setData({
          houseList: [...this.data.houseList, ...res.data.list]
        })
      } else {
        this.setData({
          msg: "加载完成"
        })
        return false
      }
    })
  },
  onReachBottom: function () {
    if (this.data.msg === "加载中...") {
      this.getMoreList()
    } else {
      return false
    }
  },
  reMove(e) {
    let that = this
    wx.showModal({
      confirmColor: '#60DC74',
      title: '温馨提示',
      content: '您是否要下架此房源？',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          let url = "/applet/broker/mymodule/house/soldOutMyHouse"
          let data = {
            pId: e.currentTarget.dataset.id
          }
          app.$http.post(url, data).then((res) => {
            console.log(res)
          }).then(() => {
            that.setData({
              'sendData.pageNumber': 1,
            })
            wx.pageScrollTo({
              scrollTop: 0
            })
            that.getList()
          })
        }
      }
    })

  },
  toRelease() {
    wx.reLaunch({
      url: '../release/release'
    })
  },
  toDetail(e) {
    console.log(e.currentTarget.dataset.id)
    if (e.currentTarget.dataset.state == 2) {
      wx.navigateTo({
        url: "/pages/secondHandHouse/secondHandHouse?id=" + e.currentTarget.dataset.id
      })
    }
  },
  onPullDownRefresh() {//刷新
    wx.showToast({
      title: '加载中....',
      icon: 'loading'
    })
    let that = this
    //模拟加载
    setTimeout(function () {
      //点击刷新
      that.setData({
        'sendData.pageNumber': 1,
        ScrollTop: 0,
        msg: "加载中..."
      })
      that.getList()
      wx.hideLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
})