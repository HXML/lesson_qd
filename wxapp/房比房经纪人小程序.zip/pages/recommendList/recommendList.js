// pages/recommendList/recommendList.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (wx.getStorageSync('login')) {
      this.getList()
    }
  },
  getList() {
    let userInfor = wx.getStorageSync('userInfor')
    let url = "/applet/broker/invitation/findInvitationById"
    let data = {
      userId: userInfor.id
    }
    app.$http.post(url, data).then((res) => {
      console.log(res.data)
      this.setData({
        list: res.data.inviList.map(e => {
          return {
            create_time: this.StringToDate(e.create_time),
            id: e.id,
            image: e.image,
            mobile: e.mobile,
            nick_name: e.nick_name,
          }
        })
      })
    })
  },
  StringToDate(DateStr) {
    let myDate = new Date(DateStr);
    console.log(myDate)
    return myDate.getFullYear() + '-' + `${myDate.getMonth() + 1}` + '-' + myDate.getDate();
  },

})