// pages/upLoadImg/upLoadImg.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Imgs: [],
    bgImg: [],
    //colorui
    urls: [],
    bgUrls: [],
    imgList: [],
    backgroundImg: [],
    //暂存IMGS
    isIphoneX: app.globalData.isIphoneX
  },
  onLoad() {
    console.log(wx.getStorageSync('backgroundImg'))
    console.log(wx.getStorageSync('imgs'))
    this.setData({
      backgroundImg: wx.getStorageSync('backgroundImg'),
      imgList: wx.getStorageSync('imgs')
    })
  },

  ViewBgImage(e) {
    wx.previewImage({
      urls: [...this.data.backgroundImg],
      current: e.currentTarget.dataset.url
    });
  },
  DelBgImg() {
    wx.showModal({
      title: '温馨提示',
      content: '确认删除此照片？',
      cancelText: '再看看',
      confirmText: '确认',
      success: res => {
        if (res.confirm) {
          this.setData({
            backgroundImg: []
          })
          wx.setStorageSync("backgroundImg", this.data.backgroundImg)//
        }
      }
    })
  },
  uploadBackground() {//上传单张
    let that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // let imgPaths = res.tempFilePaths
        // that.Upload(res.tempFilePaths[0])
        that.Upload(res.tempFilePaths[0], false)
      },
      // complete:function(res){

      // }
    })
  },



  //图片组
  //colorui
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },
  DelImg(e) {
    wx.showModal({
      title: '温馨提示',
      content: '确认删除此照片？',
      cancelText: '再看看',
      confirmText: '确认',
      success: res => {
        if (res.confirm) {
          this.data.imgList.splice(e.currentTarget.dataset.index, 1);
          this.setData({
            imgList: this.data.imgList
          })
          wx.setStorageSync("imgs", this.data.imgList)//
        }
      }
    })
  },
  //colorui
  upLoadImgs() {//上传多张
    if (this.data.backgroundImg.length == 0) {
      wx.showModal({
        title: '温馨提示',
        content: '请先上传首图',
        cancelText: '取消',
        confirmText: '确认',
      })
    } else {
      let that = this
      wx.chooseImage({
        count: 8 - this.data.imgList.length, // 默认9
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (res) {
          // let imgPaths = res.tempFilePaths
          // that.Upload(res.tempFilePaths[0])
          let imgPaths = res.tempFilePaths
          res.tempFilePaths.forEach((e, index) => {
            that.Upload(res.tempFilePaths[index], true)
          })
        }
      })
    }


  },

  Upload(imgPath, group) {
    //group判断单张还是多张
    let that = this
    wx.request({
      url: 'https://applet.fbfcn.com/e/oss/getSignature',
      // url:'http://tunnel.fbfcn.com/e/oss/getSignature',
      header: {
        'token': wx.getStorageSync('token')
      },
      success(ress) {
        console.log(ress, '获取oss的token')
        let { accessid, dir, policy, signature } = ress.data
        var guid = that.genRandomString(32)
        wx.uploadFile({
          url: 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com',
          filePath: imgPath,
          name: 'file',
          formData: {
            'name': imgPath,
            'key': dir + guid + '.png',
            'OSSAccessKeyId': accessid,
            'policy': policy,
            'signature': signature,
            'success_action_status': '200'
          },
          success(resss) {
            console.log('https://fangbifang.oss-cn-shenzhen.aliyuncs.com/' + dir + guid + '.png')
            if (group) {
              that.setData({
                Imgs: [...wx.getStorageSync('imgs'), 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com/' + dir + guid + '.png'],
                imgList: [...wx.getStorageSync('imgs'), 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com/' + dir + guid + '.png']
              })
              wx.setStorageSync("imgs", that.data.Imgs)//
            } else {
              that.setData({
                backgroundImg: ['https://fangbifang.oss-cn-shenzhen.aliyuncs.com/' + dir + guid + '.png']
              })
              wx.setStorageSync("backgroundImg", that.data.backgroundImg)//
            }
          }
        })
      }
    })
  },
  genRandomString(len) {
    const text = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const rdmIndex = text => Math.random() * text.length | 0;
    let rdmString = '';
    for (; rdmString.length < len; rdmString += text.charAt(rdmIndex(text)));
    return rdmString;
  },
  Successed() {
    console.log(this.data.backgroundImg)
    console.log(this.data.imgList)
    wx.switchTab({
      url: '/pages/release/release'
    })
    wx.setStorageSync("backgroundImg", this.data.backgroundImg)//
    wx.setStorageSync("imgs", this.data.imgList)//
  }
})