import Dialog from '../../vantui/dialog/dialog';
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: "",
    nickName: "",
    phone: "",
    login: false,
    message: "确认要退出当前账号吗?",
    userInformation: ""
  },
  onShow: function () {
    let login = wx.getStorageSync('login');
    this.setData({
      login: login
    })
    let userInfor = wx.getStorageSync("userInfor")
    if (userInfor) {
      this.setData({
        phone: userInfor.mobile,
        avatarUrl: userInfor.image ? userInfor.image : "../../images/tx.png"
      })
      this.setData({
        nickName: userInfor.nick_name ? userInfor.nick_name : userInfor.mobile.replace(/^(\d{4})\d{4}(\d+)/, "$1****$2")
      })
    }
  },
  changeNickName(e) {
    console.log(e.currentTarget.dataset.nickname)
    wx.navigateTo({
      url: '../editInfor/editInfor?name=' + e.currentTarget.dataset.nickname
    })
  },
  genRandomString (len) {
    const text = 'abcdefghijklmnopqrstuvwxyz0123456789';
    const rdmIndex = text => Math.random() * text.length | 0;
    let rdmString = '';
    for (; rdmString.length < len; rdmString += text.charAt(rdmIndex(text)));
    return rdmString;
  },
  changeTouxiang() {
    let that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        let imgPath=res.tempFilePaths[0]
        wx.request({
          url:'https://applet.fbfcn.com/e/oss/getSignature',
         // url:'http://tunnel.fbfcn.com/e/oss/getSignature',
          header: {
            'token':wx.getStorageSync('token')
          },
          success(ress) {
            console.log(ress,'获取oss的token')
            let {accessid,dir,policy,signature}=ress.data
            var guid=that.genRandomString(32)
            wx.uploadFile( {
              url: 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com',
              filePath: imgPath,
              name: 'file',
              formData: {
                'name':imgPath,
                'key': dir+guid+'.png',
                'OSSAccessKeyId': accessid,
                'policy': policy,
                'signature': signature,
                'success_action_status': '200'
              },
              success (resss) {
                console.log(res,'上传到oss的response')
                if (resss.statusCode===200) {
                  // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                  let userInfor = wx.getStorageSync("userInfor")
                  let url = "/applet/broker/myInformation/upBrokerInformation"
                  let data = {
                    image: 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com/'+dir+guid+'.png',
                    userId: userInfor.id,
                    name: userInfor.nick_name
                  }
                  app.$http.post(url, data).then((res) => {
                    console.log(res.data)
                    if (res.code == 200) {
                      wx.setStorageSync("userInfor",res.data)//个人信息
                      that.setData({
                        avatarUrl: res.data.image,
                      })

                    }
                  })
                }

              }
            })
          }
        })

        // wx.uploadFile({
        //   url: '/your_url/receive_file', // 图片上上传的地址，请求方式默认为POST且不可更改
        //   filePath: tempFilePaths[0], // 要上传的文件的路径，注：一次只能上传一个文件，若要上传多张图片，请使用递归
        //   name: 'file', // 文件对应的键名，后端可以通过这个key获取到文件的二进制内容
        //   formData: {
        //     'user_id': '123',
        //     'name': 'Jack',
        //     'age': 18
        //   },
        //   success: function (res) {
        //     var data = res.data
        //     //do something
        //   }
        // })

      }
    })
  },
  logOut() {
    wx.showModal({
      title: '确认退出',
      content: '确认要退出当前账号吗?',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.setStorageSync("token", null)
          wx.setStorageSync("login", null)
          wx.setStorageSync("userInfor", null)
          wx.setStorageSync("brokerRegionInfo", null)
          wx.setStorageSync("openid", null)
          wx.switchTab({
            url: '../index/index'
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })





    // Dialog.confirm({
    //   title: '确认退出',
    //   message: this.data.message
    // }).then(() => {
    //   wx.setStorageSync("token", null)
    //   wx.setStorageSync("login", null)
    //   wx.setStorageSync("userInfor", null)
    //   wx.setStorageSync("brokerRegionInfo", null)
    //   wx.setStorageSync("openid", null)
    //   // wx.setStorageSync("newDate", null)
    // }).then(() => {
    //   wx.switchTab({
    //     url: '../index/index'
    //   })
    // }).catch((err) => {
    //   console.log(err)
    // })
  },
})
