// pages/secondHandHouse/secondHandHouse.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiper: ["http://fangbifang.oss-cn-shenzhen.aliyuncs.com/backstage/jDB7fi_1571217373711.jpg"],
    houseInfor: '',
    grayshow: false,//画廊
    isIphoneX: app.globalData.isIphoneX,
    current: 1,
    login: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.id,"aaaaaaaaaaaaaaaaaaaa")
    // this.getHouseDetail("072a3132611541dcb4277949104c7aa9")
    this.getHouseDetail(options.id)
    this.setData({
      login: wx.getStorageSync('login')
    })
  },
  getHouseDetail(id) {
    let data = {
      housingId: id
    }
    let url = "/applet/broker/housingrec/pesonhouse/getEPersonHouseInfo"
    app.$http.post(url, data).then((res) => {
      this.setData({
        houseInfor: {
          address: res.data.address,
          area: res.data.area,
          position: res.data.position,
          broker_id: res.data.broker_id,
          broker_image: res.data.broker_image,
          broker_mobile: res.data.broker_mobile,
          broker_name: res.data.broker_name,
          broker_sum: res.data.broker_sum,
          city: res.data.city,
          decorate_status: res.data.decorate_status,
          district: res.data.district,
          house_introduce: res.data.house_introduce,
          id: res.data.id,
          cover_image: res.data.cover_image,
          images: [res.data.cover_image, ...res.data.images.split(',')],
          mobile: res.data.mobile,
          name: res.data.name,
          province: res.data.province,
          sell_house_price: res.data.sell_house_price,
          street: res.data.street,
          type: res.data.type,
          type_balcony_num: res.data.type_balcony_num,
          type_parlor_num: res.data.type_parlor_num,
          type_room_num: res.data.type_room_num,
          type_toilet_num: res.data.type_toilet_num,
        }
      })
      console.log(this.data.houseInfor)
    })
  },
  showGallery() {
    this.setData({
      grayshow: true
    })
  },
  // showGallery(e) {
  //   // let src = e.currentTarget.dataset.img;//获取data-src
  //   console.log(e)
  //   //图片预览
  //   wx.previewImage({
  //     current: e.currentTarget.dataset.cu, // 当前显示图片的http链接
  //     urls: e.currentTarget.dataset.img // 需要预览的图片http链接列表
  //   })
  // },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: `【${this.data.houseInfor.position}】${this.data.houseInfor.district}  ${this.data.houseInfor.sell_house_price}万`,
      path: `/pages/secondHandHouse/secondHandHouse?id=` + this.data.houseInfor.id,
      imageUrl: this.data.houseInfor.cover_image,
      success: function (res) {
        // 转发成功
        // console.log("转发成功:" + JSON.stringify(res));
      },
    }
  },

  callHim(e) {
    let login = wx.getStorageSync('login')
    if (!login) {
      this.setData({
        showPop: true
      })
    } else {
      console.log(e.currentTarget.dataset.mobile)
      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.mobile //仅为示例，并非真实的电话号码
      })
    }
  },
  bindSwiperChange(event) {//切换的事件
    let index = 0
    if (index > this.data.houseInfor.images.length) {
      index = this.data.houseInfor.images.length + 1
    } else {
      index = event.detail.current + 1
    }
    this.setData({
      current: index
    })
  },
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
  showLogin() {
    this.setData({ showPop: true });
  },
})
