// pages/about/home/home.js
const app = getApp()
import { formatTime2 } from '../../utils/util.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    login: false,
    VipTimer: '充值会员,享受更多特权',
    phone: '',
    price: '',
    month_nums: '',
    userInfor: "",
    touxiang: "../../images/tx.png",
    showPop: false,
  },
  onShow() {
    this.getPrie()
    let login = wx.getStorageSync('login')
    if (login) {
      let userInfor = wx.getStorageSync('userInfor')
      this.setData({
        login: login,
        phone: userInfor.nick_name ? userInfor.nick_name : userInfor.mobile,
        touxiang: userInfor.image ? userInfor.image : "../../images/tx.png"
      })
    } else {
      this.setData({
        login: false
      })
    }
  },
  add0(m) { return m < 10 ? '0' + m : m },
  timestampToString(shijianchuo) {
    var time = new Date(shijianchuo);
    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    return y + '年' + this.add0(m) + '月' + this.add0(d) + "日";
  },

  onLoad() {
    let login = wx.getStorageSync('login')
    if (login) {
      let userInfor = wx.getStorageSync('userInfor')
      this.setData({
        userInfor: userInfor,
        touxiang: userInfor.image ? userInfor.image : "../../images/tx.png"
      })
      this.setData({
        login: login,
      })

    }
  },
  getPrie() {
    let url = '/applet/broker/homepage/findBuetails'
    app.$http.get(url).then((res) => {
      console.log(res)
      this.setData({
        price: res.data[1].price,
        month_nums: res.data[1].month_nums
      })
    })
  },
  toLogin() {
    wx.navigateTo({
      url: '../login/login'

    })
  },
  toShare() {
    wx.navigateTo({
      url: "../invitation/invitation"
    })
  },
  toList() {
    wx.navigateTo({
      url: "../recommendList/recommendList"
    })
  },
  toQuanyi() {
    wx.navigateTo({
      url: "../equity/equity"
    })
  },
  onShareAppMessage: function (options) {
    if (options.from == 'menu') {
      console.log('666')
      // 来自页面内转发按钮/
    } else {
      let userInfor = wx.getStorageSync('userInfor')
      return {
        title: `邀请好友`,
        path: `/pages/index/index?invitationId=` + userInfor.id,
        imageUrl: `http://fangbifang.oss-cn-shenzhen.aliyuncs.com/backstage/jAQCts_1577329864412.png`,
        success: function (res) {
          // 转发成功
          // console.log("转发成功:" + JSON.stringify(res));
        },
      }
    }

  },
  showLogin() {
    this.setData({ showPop: true });
  },
  toMyHouse() {
    if (this.data.login) {
      wx.navigateTo({
        url: '/pages/myHouse/myHouse'
      })
    } else {
      this.setData({ showPop: true });
    }

  },
  //弹窗时间
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
})
