// pages/newHouseList/newHouseList.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    login: false,
    grayshow: false,//画廊
    list: {
      images: ['http://fangbifang.oss-cn-shenzhen.aliyuncs.com/backstage/jDB7fi_1571217373711.jpg']
    },
    houseList: [],
    sendData: {
      pageNumber: 1,
      pageSize: 4,
      city: ""
    },
    swiperList: [],
    msg: "加载中...",
  },
  onLoad() {
    this.setData({
      'sendData.city': wx.getStorageSync('cityName'),
      login: wx.getStorageSync('login'),
    })
    this.getList()
    this.getBanner()

  },
  showGallery() {
    this.setData({
      grayshow: true
    })
  },
  toDetail(e) {
    wx.navigateTo({
      url: "/pages/newHouse/newHouse?id=" + e.currentTarget.dataset.id
    })
  },
  getList() {
    let data = this.data.sendData
    let url = "/applet/broker/housingrec/newhousing/pageListDevHouse"
    app.$http.post(url, data).then((res) => {
      console.log(res)
      this.setData({
        houseList: res.data.list
      })
    })
  },
  //分享
  onShareAppMessage: function (options) {
    if (options.from == 'menu') {
      console.log('666')
      // 来自页面内转发按钮/
    } else {
      console.log("分享")
      console.log(options.target.dataset)
      return {
        title: `【${options.target.dataset.title}】 ${options.target.dataset.district} ${options.target.dataset.price}元/㎡ `,
        path: `/pages/newHouse/newHouse?id=` + options.target.dataset.id,
        imageUrl: options.target.dataset.img,
        success: function (res) {
          // 转发成功
          // console.log("转发成功:" + JSON.stringify(res));
        },
      }
    }
  },
  getBanner() {//获取首页的轮播图
    let _this = this
    let url2 = "/adv/listAdvertisingSpace"
    app.$http.get(url2).then(res => {
      console.log(res)
      let item = res.data.find(e => {
        return e.tag == "ejj_person_house"
        // return e.tag == "person_house_choiceness"
      })
      console.log(item)
      //根据广告列表查询首页的广告栏
      let data3 = {
        aId: item.id,
        city: "深圳市"
      }
      let ulr3 = "/adv/listAdvertising"
      app.$http.post(ulr3, data3).then(res => {
        console.log('444444444444444', res)
        _this.setData({
          swiperList: res.data.map(e => {
            return e.bg_image
          })
        })
      })
    })
  },
  getMoreList() {
    this.setData({
      'sendData.pageNumber': this.data.sendData.pageNumber + 1
    })
    let data = this.data.sendData
    let url = "/applet/broker/housingrec/newhousing/pageListDevHouse"
    app.$http.post(url, data).then((res) => {
      console.log(res)
      if (res.data.totalRow > this.data.houseList.length) {
        this.setData({
          houseList: [...this.data.houseList, ...res.data.list]
        })
      } else {
        this.setData({
          msg: "加载完成"
        })
        return false
      }

    })
  },
  onReachBottom: function () {
    if (this.data.msg === "加载中...") {
      this.getMoreList()
    }
  },
  onPullDownRefresh() {//刷新
    wx.showToast({
      title: '加载中....',
      icon: 'loading'
    })

    let that = this
    //模拟加载
    setTimeout(function () {
      //点击刷新
      that.setData({
        'sendData.pageNumber': 1,
        ScrollTop: 0,
        msg: '加载中...'
      })
      that.getList()
      wx.hideLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
  showLogin() {
    this.setData({ showPop: true });
  },
  //弹窗时间
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
})