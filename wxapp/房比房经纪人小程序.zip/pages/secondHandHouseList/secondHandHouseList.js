// pages/secondHandHouseList/secondHandHouseList.js
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    sameCity: false,
    activeIndex: '0',
    lineStyle: "",
    translateNumber: '',
    showPOP: false,//弹窗
    hxopen: false,
    hxshow: true,
    isfull: false,
    room: ['1室', '2室', '3室', '4室', '5室', '5室以上'],
    price: ['200万以下', '200-300万', '300-400万', '400-500万', '500-800万', '1000万以上'],
    decoration: ['普装', '精装', '豪装', '毛坯'],
    activeRoom: [],//多选
    activeRoomName: "",//委托时候的是单选
    activePrice: [],//多选
    activeDecorationIndex: '',//单选
    //点击筛选时的状态
    // PreActiveRoom: [],//多选
    // PreActivePrice: [],//多选
    // PreActiveDecorationIndex: '',//单选
    //点击筛选时的状态
    sendData: {
      pageNumber: 1,
      pageSize: 6,
      type: 2,    //房源类型（1为普通房源，2为优质房源
      model: "",//户型1-5 直接传数字，不限传"" 5室以上就传5室以上
      price: "",//-
      decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
      province: "",//省级行政区
      city: "",//市级行政区
      district: "",//区
      street: "",//街道
    },
    houseList: [],
    //下拉加载
    msg: "加载中...",
  },
  getSecondhandList(type) {
    let url = "/applet/broker/housingrec/pesonhouse/findPageEPersonHouse"
    this.setData({
      'sendData.type': type
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      this.setData({
        houseList: res.data.list.map(e => {
          return {
            address: e.address,
            area: e.area,
            city: e.city,
            decorate_status: e.decorate_status,
            district: e.district,
            id: e.id,
            mobile: e.mobile,
            name: e.name,
            position: e.position,
            province: e.province,
            sell_house_price: e.sell_house_price,
            street: e.street,
            type_balcony_num: e.type_balcony_num,//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
            type_parlor_num: e.type_parlor_num,//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
            type_room_num: e.type_room_num,//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
            type_toilet_num: e.type_toilet_num,//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
          }
        })
      })
    })
  },
  tapItem(e) {
    this.setData({
      'sendData.model': '',
      activeRoom: [],
      activeRoomName: "",
      msg: "加载中...",
      activePrice: [],
      activeDecorationIndex: "",
      sendData: {
        pageNumber: 1,
        pageSize: 6,
        model: "",//户型1-5 直接传数字，不限传"" 5室以上就传5室以上
        price: "",//-
        decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
        province: '',//省级行政区
        city: wx.getStorageSync('cityName'),
        district: '',//区
        street: '',//街道
      },
    })
    console.log(e.currentTarget.dataset.index)
    if (!this.data.showPOP) {
      this.setData({
        activeIndex: e.currentTarget.dataset.index,
      })
      if (e.currentTarget.dataset.index == 0) {
        this.setData({
          'sendData.pageNumber': 1,
          msg: "加载中..."
        })
        this.setLine(0)
        this.getSecondhandList(2)
      }
      if (e.currentTarget.dataset.index == 1) {
        this.setData({
          'sendData.pageNumber': 1,
          msg: "加载中..."
        })
        this.getSecondhandList(1)
        this.setLine(185)
      }
      if (e.currentTarget.dataset.index == 2) {
        this.setData({
          'sendData.pageNumber': 1,
          activeRoom: [],
          msg: "加载中..."
        })
        this.setLine(370)
        this.getWeituoList(1)
      }
    }


  },
  getWeituoList(type) {
    let url = "/applet/broker/homepage/findPageEntrustList"
    this.setData({
      'sendData.type': type
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      this.setData({
        houseList: res.data.list.map(e => {
          return {
            area: e.area,
            building_no: e.building_no,
            community_name: e.community_name,
            id: e.id,
            mobile: e.mobile,
            model: e.model,
            name: e.name,
            rent_price: e.rent_price,
            sell_price: e.sell_price,
          }
        })
      })
    })
  },
  toHouseDetail(e) {
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: "/pages/secondHandHouse/secondHandHouse?id=" + e.currentTarget.dataset.id
    })
  },
  showPOP() {
    // console.log(this.data.PreActiveRoom)
    // console.log(this.data.PreActivePrice)
    // console.log(this.data.PreActiveDecorationIndex)
    // if (this.data.showPOP) {
    //   this.setData({
    //     //记录点击筛选前的状态
    //     PreActiveRoom: this.data.activeRoom,
    //     PreActivePrice: this.data.activePrice,
    //     PreActiveDecorationIndex: this.data.activeDecorationIndex,
    //     //记录点击筛选前的状态
    //   })
    // }
    this.setData({
      // activeIndex: e.currentTarget.dataset.index,
      showPOP: !this.data.showPOP,
      hxopen: !this.data.hxopen,
      hxshow: !this.data.hxshow,
      isfull: !this.data.isfull
    })
  },
  addToRoom(e) {//委托的单独处理
    if (this.data.activeIndex == "2") {
      console.log(e.currentTarget.dataset.room)//发送给后台的
      if (e.currentTarget.dataset.room == "不限") {
        this.setData({
          activeRoomName: '',
          indexRoomName: ''////发送给后台的
        })
      } else {
        this.setData({
          activeRoomName: e.currentTarget.dataset.room,
          indexRoomName: e.currentTarget.dataset.room == "5室以上" ? "6" : e.currentTarget.dataset.room[0]//发送给后台的
        })
      }
      console.log(this.data.indexRoomName)
    } else {///点击加入多选room
      console.log("多选")
      if (e.currentTarget.dataset.room == "不限") {
        this.setData({
          activeRoom: []
        })
      } else {
        let result = this.data.activeRoom.find(item => {
          return item === e.currentTarget.dataset.room
        });
        let newArr = this.data.activeRoom
        if (result !== undefined) {
          let nid = newArr.indexOf(result);
          newArr.splice(nid, 1)//删除某个数组
          this.setData({
            activeRoom: newArr,
          })
        } else {
          newArr.push(e.currentTarget.dataset.room)
          this.setData({
            activeRoom: [...new Set(newArr)],
          })
        }
      }
    }
  },
  addToPrice(e) {//点击加入多选价格
    if (e.currentTarget.dataset.price == "不限") {
      this.setData({
        activePrice: [],
      })
    } else {
      // console.log(e.currentTarget.dataset.price)
      let result = this.data.activePrice.find(item => {
        return item === e.currentTarget.dataset.price
      });
      // console.log(result)
      let newArr = this.data.activePrice
      if (result !== undefined) {
        let nid = newArr.indexOf(result);
        newArr.splice(nid, 1)//删除某个数组
        this.setData({
          activePrice: newArr
        })
      } else {
        newArr.push(e.currentTarget.dataset.price)
        this.setData({
          activePrice: [...new Set(newArr)],
        })
      }
    }

  },
  addDeriction(e) {//点击加入装修 单选
    console.log(e.currentTarget.dataset.state)
    this.setData({
      activeDecorationIndex: e.currentTarget.dataset.state == "不限" ? '' : e.currentTarget.dataset.state
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setLine(0)
    this.setData({//冲了钱的区域信息赋值
      'sendData.city': this.data.sameCity ? '' : wx.getStorageSync('cityName'),
    })
    this.getSecondhandList(2)
  },
  onClose() {
    this.setData({ show: false });
  },
  setLine(left) {//动态改变切换
    this.setData({
      lineStyle: `height:4rpx;width:120rpx;background-color: #60DC74;-webkit-transform: translateX(${left}rpx);transform: translateX(${left}rpx);transition-duration: 0.3s;
      -webkit-transition-duration: 0.3s;`
    });
  },
  toSecondDetail(e) {// 二手房详情页面
    console.log(e)
    wx.navigateTo({
      url: '../secondHandHouse/secondHandHouse'
    })
  },
  cancel() {
    // console.log(this.data.PreActiveRoom)
    // console.log(this.data.PreActivePrice)
    // console.log(this.data.PreActiveDecorationIndex)
    this.setData({
      'sendData.model': '',
      activeRoom: [],
      activeRoomName: "",
      msg: "加载中...",
      activePrice: [],
      activeDecorationIndex: "",
      indexRoomName: "",
      // showPOP: !this.data.showPOP,
      // hxopen: false,
      // hxshow: true,
      // isfull: false,
      // activeRoom: this.data.PreActiveRoom,
      // activePrice: this.data.PreActivePrice,
      // activeDecorationIndex: this.data.PreActiveDecorationIndex,
    })
  },
  confirm() {
    this.setData({
      'sendData.pageNumber': 1,
      msg: "加载中..."
    })
    console.log(this.data.activeIndex)
    if (this.data.activeIndex === '2') {
      console.log(this.data.indexRoomName)
      this.setData({
        'sendData.model': this.data.indexRoomName
      })
    } else {
      this.setData({
        'sendData.model': this.data.activeRoom === [] ? "" : this.data.activeRoom.map(e => {
          if (e === "5室以上") {
            return 6
          } else {
            return e[0]
          }
        }).join(','),
      })
    }
    this.setData({
      'sendData.price': this.data.activePrice === [] ? "" : this.data.activePrice.map(e => {
        if (e === "1000万以上") {
          return '1000-'
        } else if (e === '200万以下') {
          return '0-200'
        } else {
          return e.substring(0, 7)
        }
      }).join(','),
      'sendData.decorate_status': this.data.activeDecorationIndex,
      showPOP: !this.data.showPOP,
      hxopen: !this.data.hxopen,
      hxshow: !this.data.hxshow,
      isfull: !this.data.isfull
    })
    if (this.data.activeIndex == '2') {
      this.getWeituoList(1)
    } else if (this.data.activeIndex === "0") {
      this.getSecondhandList(2)
      console.log("加载优质二手房")
    } else {
      console.log("加载普通二手房")
      this.getSecondhandList(1)
    }
  },
  hidebg() {
    this.setData({
      hxopen: false,
      hxshow: true,
      isfull: false
    })
  },
  callHim(e) {
    let login = wx.getStorageSync('login')
    if (!login) {
      this.setData({
        showLogin: true
      })
    } else {
      console.log(e.currentTarget.dataset.mobile)
      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.mobile //仅为示例，并非真实的电话号码
      })
    }
  },
  getMoreList(type) {
    console.log('获取二手房信息')
    let url = "/applet/broker/housingrec/pesonhouse/findPageEPersonHouse"
    this.setData({
      'sendData.type': type,
      'sendData.pageNumber': this.data.sendData.pageNumber + 1
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      let newArr = res.data.list.map(e => {
        return {
          address: e.address,
          area: e.area,
          city: e.city,
          decorate_status: e.decorate_status,
          district: e.district,
          id: e.id,
          mobile: e.mobile,
          name: e.name,
          position: e.position,
          province: e.province,
          sell_house_price: e.sell_house_price,
          street: e.street,
          type_balcony_num: e.type_balcony_num,//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
          type_parlor_num: e.type_parlor_num,//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
          type_room_num: e.type_room_num,//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
          type_toilet_num: e.type_toilet_num,//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
        }
      })
      if (res.data.totalRow > this.data.houseList.length) {
        this.setData({
          houseList: [...this.data.houseList, ...newArr]
        })
      } else {
        this.setData({
          msg: "加载完成"
        })
        return false
      }

    })
  },
  getMoreWeituo() {
    console.log('获取更多委托信息')
    let url = "/applet/broker/homepage/findPageEntrustList"
    this.setData({
      'sendData.type': 1,
      'sendData.pageNumber': this.data.sendData.pageNumber + 1
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      let morelist = res.data.list.map(e => {
        return {
          area: e.area,
          building_no: e.building_no,
          community_name: e.community_name,
          id: e.id,
          mobile: e.mobile,
          model: e.model,
          name: e.name,
          rent_price: e.rent_price,
          sell_price: e.sell_price,
        }
      })
      if (res.data.totalRow > this.data.houseList.length) {
        this.setData({
          houseList: [...this.data.houseList, ...morelist]
        })
      } else {
        this.setData({
          msg: "加载完成"
        })
        return false
      }
    })
  },
  onReachBottom: function () {
    console.log(this.data.activeIndex)
    if (this.data.activeIndex == '2') {
      if (this.data.msg === "加载中...") {
        this.getMoreWeituo()
      }
    } else if (this.data.activeIndex == 0) {
      if (this.data.msg === "加载中...") {
        console.log('加载二手房')
        this.getMoreList(2)
      }
    } else if (this.data.activeIndex == 1) {
      console.log('加载二手房')
      if (this.data.msg === "加载中...") {
        console.log('加载二手房')
        this.getMoreList(1)
      }
    }
  },

  onPullDownRefresh() {//刷新
    wx.showToast({
      title: '加载中....',
      icon: 'loading'
    })
    let that = this
    //模拟加载
    setTimeout(function () {
      //点击刷新
      that.setData({
        'sendData.pageNumber': 1,
        ScrollTop: 0,
        msg: '加载中...'
      })
      if (that.data.activeIndex == '2') {
        that.getWeituoList(1)
      } else if (that.data.activeIndex == '0') {
        that.getSecondhandList(2)
      } else if (that.data.activeIndex == '1') {
        that.getSecondhandList(1)
      }
      wx.hideLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
  getPhoneNumber() {
    this.setData({ showLogin: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showLogin: false });
  },
})