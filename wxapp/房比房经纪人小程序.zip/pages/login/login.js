// pages/login/login.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    code: ''
  },

  toPhoneLogin(e) {
    console.log(e)
    let data = {
      iv: e.detail.iv,
      encryptedData: e.detail.encryptedData
    }
    wx.setStorageSync('scretMsg', data)
    wx.navigateTo({
      url: '../phoneLogin/phoneLogin?code=' + this.data.code
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.login({
      success: res => {
        console.log(res)
        this.setData({
          code: res.code
        })
      }
    })
  },
  getPhoneNumber(e) {
    console.log(e)
    if (e.detail.encryptedData && e.detail.iv) {
      let { encryptedData, iv } = e.detail
      if (this.data.code) {
        let data = {
          encryptedData,
          iv,
          code: this.data.code,
          invitation_user_id: wx.getStorageSync('invitationId')
        }
        let url = "/applet/broker/login"
        app.$http.post(url, data).then(res => {
          console.log(res)
          let brokerRegionInfo = res.data.brokerRegionInfo//是否充值
          let userInfor = {
            gender: res.data.userinfo.gender,
            id: res.data.userinfo.id,
            image: res.data.userinfo.image,
            mobile: res.data.userinfo.mobile,
            nick_name: res.data.userinfo.nick_name,
            status: res.data.userinfo.status
          }
          wx.setStorageSync("token", res.data.token)//token
          wx.setStorageSync("login", true)//登录状态
          wx.setStorageSync("userInfor", userInfor)//个人信息
          wx.setStorageSync("brokerRegionInfo", brokerRegionInfo)//是否充值  充值了的话 直接跳到
          wx.setStorageSync("openid", res.data.openid)
          wx.switchTab({
            url: '../index/index'
          })
        })

      }

    }

  },
  Intercept(e) {
    return e.replace(/^(\d{4})\d{4}(\d+)/, "$1****$2")
  },
})
