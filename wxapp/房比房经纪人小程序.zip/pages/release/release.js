// pages/release/release.js
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        disChange: false,
        showPop: false,
        Checked: true,
        radio: '1',
        texts: "至少5个字",
        min: 5,//最少字数
        max: 300, //最多字数 (根据自己需求改变)
        //  区域选择
        provinceName: "",
        cityName: "",
        areaName: "",
        streetName: "",
        multiArray: [
            ["广东省"],
            ['深圳市'],
            ['罗湖区', '宝安区',],
            ["北街街道"]//初始值 会被覆盖
        ],
        multiIndex: [18, 15, 5, 0],
        modelArray: [
            ["1室", "2室", "3室", "4室", "5室", "6室", "7室", "8室", "9室", "10室", "11室", "12室", "13室", "14室", "15室"],
            ['0厅', "1厅", "2厅", "3厅", "4厅", "5厅", "6厅", "7厅", "8厅", "9厅", "10厅", "11厅", "12厅", "13厅", "14厅", "15厅"],
            ['0卫', "1卫", "2卫", "3卫", "4卫", "5卫", "6卫", "7卫", "8卫", "9卫", "10卫", "11卫", "12卫", "13卫", "14卫", "15卫"],
            ['0阳台', "1阳台", "2阳台", "3阳台", "4阳台", "5阳台", "6阳台", "7阳台", "8阳台", "9阳台", "10阳台", "11阳台", "12阳台", "13阳台", "14阳台", "15阳台"],
        ],
        modelpickerHidden: false,
        modelIndex: [0, 0, 0, 0],
        DecorationArray: ["普装", "精装", "豪装", "毛坯"],
        DecorationIndex: 0,
        DecorationpickerHidden: false,
        houseTypeArray: ['普通房源', '优质房源'],
        houseTypeIndex: 0,
        houseTypepickerHidden: false,
        //发布信息
        imgTotal: '',
        cover_img: '',
        //发给后台的数据
        sendData: {
            images: "",//图片,多个用逗号隔开
            province: "",//
            city: "",//
            district: "",//
            street: "",//
            address: "详细地址",//address
            position: "",//所在小区
            house_no: "",//楼号
            area: "",//
            sell_house_price: "",//
            decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
            type_room_num: "",//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
            type_parlor_num: "",//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
            type_toilet_num: "",//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
            type_balcony_num: "",//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
            house_introduce: "",//房源介绍
            type: 1,//房源类型（1为普通房源，2为优质房源）
            name: "",//姓名
            mobile: "",//联系电话
            cover_image: ""
        }
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.getAddressChoose()
    },
    onClose() {
        this.setData({ showPop: false });
        // return false
    },
    getPhoneNumber() {
        this.setData({ showPop: false });
        wx.navigateTo({
            url: "../login/login"
        })
    },
    onShow() {
        console.log('点击了发布按钮')
        let login = wx.getStorageSync('login')
        console.log(login, 'login')
        // let brokerRegionInfo = wx.getStorageSync('brokerRegionInfo')
        // console.log(brokerRegionInfo, 'brokerRegionInfo')
        if (!login) {
            this.setData({ showPop: true });
        } else {
            this.setData({ showPop: false });
        }
        this.setData({
            'sendData.images': wx.getStorageSync('imgs') == '' || wx.getStorageSync('imgs').length == 0 ? '' : wx.getStorageSync('imgs').join(','),
            'sendData.cover_image': wx.getStorageSync('backgroundImg') == "" || wx.getStorageSync('backgroundImg').length == 0 ? '' : wx.getStorageSync('backgroundImg')[0],
            imgTotal: wx.getStorageSync('backgroundImg').length,
            imgsLength: wx.getStorageSync('imgs').length,
            cover_img: wx.getStorageSync('backgroundImg')[0] ? wx.getStorageSync('backgroundImg')[0] : ''
        })
    },
    getAddressChoose() {
        app.$http.get('/location/getAllProvince').then((res) => {//获取所有的省 放入第一个列
            this.setData({
                'multiArray[0]': res.data.map(e => {
                    return e.PROVINCE_NAME
                })
            })
        })
        app.$http.post('/location/getAllCityByProvinceCode', { provinceCode: '广东省' }).then((res) => {//获取默认省下面的所有市 放入第二个列
            let a = res.data.map(e => {
                return e.CITY_NAME
            })
            console.log(a, 'aaaaaaaaaaaa')
            this.setData({
                'multiArray[1]': res.data.map(e => {
                    return e.CITY_NAME
                })
            })
        })

        let url2 = "/location/getAllAreaByCityCode"
        let data = {
            cityCode: "深圳市"
        }
        app.$http.post(url2, data).then((res) => {//获取第一个市的下面的所有区
            this.setData({
                'multiArray[2]': res.data.map(e => {
                    return e.AREA_NAME
                })
            })
        })
        app.$http.post("/location/getAllStreetByAreaCode", {
            areaCode: "罗湖区"
        }).then((res) => {//获取第一个区下面的所有街道
            console.log(res)
            this.setData({
                'multiArray[3]': res.data.map(e => {
                    return e.STREET_NAME
                })
            })
        })
    },
    toUpLoadImg() {
        if (this.data.cover_img !== "") {
            wx.navigateTo({
                url: "/pages/upLoadImg/upLoadImg"
            })
        }
    },
    toUpLoadImg2() {
        wx.navigateTo({
            url: "/pages/upLoadImg/upLoadImg"
        })
    },
    previewImage: function (e) {
        wx.previewImage({
            current: e.currentTarget.src, // 当前显示图片的http链接
            urls: this.data.urls // 需要预览的图片http链接列表
        })
    },
    changeTouxiang() {
        let that = this
        wx.chooseImage({
            count: 10, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                // let imgPaths = res.tempFilePaths
                // that.Upload(res.tempFilePaths[0])
                let imgPaths = res.tempFilePaths
                res.tempFilePaths.forEach((e, index) => {
                    that.Upload(res.tempFilePaths[index])
                })
            }
        })
    },
    Upload(imgPath) {
        let that = this
        wx.request({
            url: 'https://applet.fbfcn.com/e/oss/getSignature',
            // url:'http://tunnel.fbfcn.com/e/oss/getSignature',
            header: {
                'token': wx.getStorageSync('token')
            },
            success(ress) {
                console.log(ress, '获取oss的token')
                let { accessid, dir, policy, signature } = ress.data
                var guid = that.genRandomString(32)
                wx.uploadFile({
                    url: 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com',
                    filePath: imgPath,
                    name: 'file',
                    formData: {
                        'name': imgPath,
                        'key': dir + guid + '.png',
                        'OSSAccessKeyId': accessid,
                        'policy': policy,
                        'signature': signature,
                        'success_action_status': '200'
                    },
                    success(resss) {
                        console.log(resss, '上传到oss的response')
                        if (resss.statusCode === 200) {
                            // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                            let userInfor = wx.getStorageSync("userInfor")
                            let url = "/applet/broker/myInformation/upBrokerInformation"
                            let data = {
                                image: 'https://fangbifang.oss-cn-shenzhen.aliyuncs.com/' + dir + guid + '.png',
                                userId: userInfor.id,
                                name: userInfor.nick_name
                            }
                            app.$http.post(url, data).then((res) => {
                                console.log(res.data)
                                if (res.code == 200) {
                                    console.log(res.data.image)
                                    wx.setStorageSync("userInfor", res.data)//个人信息
                                    that.setData({
                                        Imgs: [...that.data.Imgs, res.data.image]
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    },
    genRandomString(len) {
        const text = 'abcdefghijklmnopqrstuvwxyz0123456789';
        const rdmIndex = text => Math.random() * text.length | 0;
        let rdmString = '';
        for (; rdmString.length < len; rdmString += text.charAt(rdmIndex(text)));
        return rdmString;
    },
    ///输入textarea的事件
    //字数限制
    inputs: function (e) {
        // 获取输入框的内容
        var value = e.detail.value;
        // 获取输入框内容的长度
        var len = parseInt(value.length);

        //最少字数限制
        if (len <= this.data.min)
            this.setData({
                texts: "加油，够5个字可以得20积分哦"
            })
        else if (len > this.data.min)
            this.setData({
                texts: " "
            })

        //最多字数限制
        if (len > this.data.max) return;
        // 当输入框内容的长度大于最大长度限制（max)时，终止setData()的执行
        this.setData({
            currentWordNumber: len, //当前字数
            'sendData.house_introduce': e.detail.value
        });
    },
    ///输入textarea的事件


    //地区选择器
    pickerClick() {
        console.log('点击了选择器')
        console.log(this.data.sendData)
        this.setData({
            pickerHidden: true
        })
    },
    addressCancel(e) {
        //用户取消
        console.log('用户取消')
        if (this.data.sendData.province == '') {
            this.setData({
                pickerHidden: false
            })
        }
    },
    //户型取消
    cancelHuxing() {

        console.log(this.data.sendData.type_room_num)
        if (this.data.room == '') {
            this.setData({
                modelpickerHidden: false
            })
        }
    },
    MultiChange(e) {//点击确认的时候
        this.setData({
            multiIndex: e.detail.value,
            provinceName: this.data.multiArray[0][e.detail.value[0]],
            cityName: this.data.multiArray[1][e.detail.value[1]],
            areaName: this.data.multiArray[2][e.detail.value[2]],
            street: this.data.multiArray[3][e.detail.value[3]],
            'sendData.province': this.data.multiArray[0][e.detail.value[0]],
            'sendData.city': this.data.multiArray[1][e.detail.value[1]],
            'sendData.district': this.data.multiArray[2][e.detail.value[2]],
            'sendData.street': this.data.multiArray[3][e.detail.value[3]],
        })
    },
    MultiColumnChange(e) {//列发生改变的时候
        let data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        let _this = this
        data.multiIndex[e.detail.column] = e.detail.value;
        console.log(e.detail.column)
        switch (e.detail.column) {
            case 0://第一列发生改变的时候
                let data1 = {
                    provinceCode: this.data.multiArray[0][e.detail.value]
                }
                let url1 = "/location/getAllCityByProvinceCode"
                app.$http.post(url1, data1).then((res) => {//获取所有的市 放到第二列
                    this.setData({
                        'multiArray[1]': res.data.map(e => {
                            return e.CITY_NAME
                        })
                    })
                })
                console.log(this.data.multiArray[0][data.multiIndex[0]])//拿到第二列的第一个值
                let data3 = {
                    provinceCode: this.data.multiArray[0][data.multiIndex[0]]
                }
                let url3 = "/location/getAllCityByProvinceCode"
                app.$http.post(url3, data3).then((res) => {//获取第一列下的省的第一个市
                    console.log(res.data[0].CITY_NAME)
                    this.setData({
                        firstCityName: res.data[0].CITY_NAME
                    })
                }).then(() => {
                    let data4 = {
                        cityCode: this.data.firstCityName
                    };//
                    let url4 = "/location/getAllAreaByCityCode"
                    app.$http.post(url4, data4).then((result) => {
                        console.log(result)
                        this.setData({
                            // areaName: result.data.AREA_NAME,
                            "multiArray[2]": result.data.map(e => {
                                return e.AREA_NAME
                            })
                        })
                        // console.log(this.data.multiArray[2][0])
                    }).then(() => {
                        console.log(this.data.multiArray[2][0])
                        app.$http.post("/location/getAllStreetByAreaCode", {
                            areaCode: this.data.multiArray[2][0]
                        }).then((res) => {//获取第一个区下面的所有街道
                            console.log(res)
                            this.setData({
                                'multiArray[3]': res.data.map(e => {
                                    return e.STREET_NAME
                                })
                            })
                        })
                    })
                })
                data.multiIndex[1] = 0;
                data.multiIndex[2] = 0;
                break;
            case 1:
                console.log(this.data.multiArray[1][e.detail.value])
                let data2 = {
                    cityCode: this.data.multiArray[1][e.detail.value]
                }
                let url2 = "/location/getAllAreaByCityCode"
                app.$http.post(url2, data2).then((res) => {
                    console.log(res)
                    this.setData({
                        'multiArray[2]': res.data.map(e => {
                            return e.AREA_NAME
                        })
                    })
                }).then(() => {
                    console.log(this.data.multiArray[2][0])
                    app.$http.post("/location/getAllStreetByAreaCode", {
                        areaCode: this.data.multiArray[2][0]
                    }).then((res) => {//获取第一个区下面的所有街道
                        console.log(res)
                        this.setData({
                            'multiArray[3]': res.data.map(e => {
                                return e.STREET_NAME
                            })
                        })
                    })
                })
                data.multiIndex[2] = 0;
                data.multiIndex[3] = 0;
            case 2:
                console.log(this.data.multiArray[2][e.detail.value])
                app.$http.post("/location/getAllStreetByAreaCode", {
                    areaCode: this.data.multiArray[2][e.detail.value]
                }).then((res) => {//获取第一个区下面的所有街道
                    console.log(res)
                    this.setData({
                        'multiArray[3]': res.data.map(e => {
                            return e.STREET_NAME
                        })
                    })
                })
                break;
        }
        this.setData(data);
        console.log(this.data.multiIndex, 'this.data.multiIndex')
    },
    //户型选择
    choosePicker() {
        console.log('点击了选择器')
        this.setData({
            modelpickerHidden: true
        })
    },
    modelChange(e) {//点击确认的时候
        console.log(e.detail.value[0] + 1)
        this.setData({
            modelIndex: e.detail.value,
            room: this.data.modelArray[0][e.detail.value[0]],//室
            hall: this.data.modelArray[1][e.detail.value[1]],//厅
            toilet: this.data.modelArray[2][e.detail.value[2]],//卫
            balcony: this.data.modelArray[3][e.detail.value[3]],//阳台
            'sendData.type_room_num': e.detail.value[0] + 1,//室
            'sendData.type_parlor_num': e.detail.value[1],//厅
            'sendData.type_toilet_num': e.detail.value[2],//卫
            'sendData.type_balcony_num': e.detail.value[3],//阳台
        })
    },
    modelCancel(e) {
        console.log(e)
        this.setData({
            modelIndex: this.data.modelIndex,
        })
    },
    //户型选择
    //装修
    decorationChoosePicker() {
        console.log('点击了选择器')
        this.setData({
            DecorationpickerHidden: true
        })
    },
    decorationChange(e) {//点击确认的时候
        console.log(e.detail.value)
        this.setData({
            DecorationIndex: e.detail.value,
            "sendData.decorate_status": this.data.DecorationArray[e.detail.value]
        })
    },
    decorationCancel(e) {
        console.log(e)
        this.setData({
            DecorationIndex: this.data.DecorationIndex,
        })
    },
    //装修
    //房源类型
    // houseTypeChoosePicker() {
    //   console.log('点击了选择器')
    //   this.setData({
    //     houseTypepickerHidden: true
    //   })
    // },
    // houseTypeChange(e) {//点击确认的时候
    //   console.log(Number(e.detail.value) + 1)
    //   this.setData({
    //     houseTypeIndex: e.detail.value,
    //     "sendData.type": Number(e.detail.value) + 1
    //   })
    // },
    // houseTypeCancel(e) {
    //   console.log(e)
    //   this.setData({
    //     houseTypeIndex: this.data.houseTypeIndex,
    //   })
    // },
    // 房源类型
    onChange(e) {
        console.log(e.detail, "44444")
        this.setData({
            radio: e.detail
        });
        let mobile = wx.getStorageSync('userInfor').mobile
        if (e.detail == 2) {
            this.setData({
                'sendData.mobile': mobile,
                disChange: true,
                // checkedRadio: !this.data.checkedRadio,
                "sendData.type": e.detail
            })
        } else {
            this.setData({
                'sendData.mobile': '',
                disChange: false,
                // checkedRadio: !this.data.checkedRadio,
                "sendData.type": e.detail
            })
        }
    },
    inputInfor(e) {
        console.log(e)
        if (e.currentTarget.dataset.name === "name") {
            this.setData({
                'sendData.position': e.detail.value
            })
        }
        if (e.currentTarget.dataset.name === "floor_number") {
            this.setData({
                'sendData.house_no': e.detail.value
            })
        }
        if (e.currentTarget.dataset.name === "house_area") {
            this.setData({
                'sendData.area': e.detail.value
            })
        }
        if (e.currentTarget.dataset.name === "house_price") {
            this.setData({
                'sendData.sell_house_price': e.detail.value
            })
        }
        if (e.currentTarget.dataset.name === "jjr_name") {
            this.setData({
                'sendData.name': e.detail.value
            })
        }
        if (e.currentTarget.dataset.name === "jjr_phone") {
            this.setData({
                'sendData.mobile': e.detail.value
            })
        }
    },
    submitHouseInfor() {
        let that = this
        console.log(this.data.sendData)
        // console.log(wx.getStorageSync('imgs'))
        let data = this.data.sendData
        let url = "/applet/broker/housingrec/pesonhouse/insEPersonHouse"
        app.$http.post(url, data).then((res) => {
            if (res.code == 200) {
                wx.showModal({
                    confirmColor: '#60DC74',
                    title: '温馨提示',
                    content: '房源信息已提交成功，您可在我的房源中查看审核进度！',
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            wx.setStorageSync("imgs", [])
                            wx.setStorageSync("backgroundImg", [])
                            that.setData({
                                pickerHidden: false,
                                modelpickerHidden: false,
                                DecorationpickerHidden: false,
                                houseTypepickerHidden: false,
                                currentWordNumber: 0,
                                sendData: {
                                    images: "",//图片,多个用逗号隔开
                                    province: "",//
                                    city: "",//
                                    district: "",//
                                    street: "",//
                                    address: "详细地址",//address
                                    position: "",//所在小区
                                    house_no: "",//楼号
                                    area: "",//
                                    sell_house_price: "",//
                                    decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
                                    type_room_num: "",//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
                                    type_parlor_num: "",//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
                                    type_toilet_num: "",//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
                                    type_balcony_num: "",//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
                                    house_introduce: "",//房源介绍
                                    type: 1,//房源类型（1为普通房源，2为优质房源）
                                    name: "",//姓名
                                    mobile: "",//联系电话
                                    cover_image: ""
                                }
                            })
                            wx.navigateTo({
                                url: '../myHouse/myHouse'
                            })
                        } else if (res.cancel) {
                            wx.setStorageSync("imgs", [])
                            wx.setStorageSync("backgroundImg", [])
                            that.setData({
                                pickerHidden: false,
                                modelpickerHidden: false,
                                DecorationpickerHidden: false,
                                houseTypepickerHidden: false,
                                currentWordNumber: 0,
                                sendData: {
                                    images: "",//图片,多个用逗号隔开
                                    province: "",//
                                    city: "",//
                                    district: "",//
                                    street: "",//
                                    address: "详细地址",//address
                                    position: "",//所在小区
                                    house_no: "",//楼号
                                    area: "",//
                                    sell_house_price: "",//
                                    decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
                                    type_room_num: "",//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
                                    type_parlor_num: "",//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
                                    type_toilet_num: "",//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
                                    type_balcony_num: "",//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
                                    house_introduce: "",//房源介绍
                                    type: 1,//房源类型（1为普通房源，2为优质房源）
                                    name: "",//姓名
                                    mobile: "",//联系电话
                                    cover_image: ""
                                }
                            })
                            wx.switchTab({
                                url: '../index/index'
                            })
                        }
                    }
                })
            } else {
                console.log(res.msg)
                wx.showModal({
                    confirmColor: '#60DC74',
                    title: '温馨提示',
                    content: res.msg,
                })
            }
        })

    },
    toXieyi() {
        wx.navigateTo({
            // url: '/pages/recharge/recharge'
            url: '/pages/agreement/agreement'
        })
    },
    changeCheack() {
        this.setData({
            Checked: !this.data.Checked
        })
        // console.log(this.data.Checked)
    },
    prevent() {
    }
})
