// pages/basics/recharge/recharge.js
var util = require('../../utils/util');
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    price: '',
    firstCityName: '',
    month_nums: '',
    multiArray: [
      ["广东省"],
      ['深圳市'],
      ['龙华新区', '宝安区',]//初始值 会被覆盖
    ],
    multiIndex: [18, 15, 5],
    provinceName: "",
    cityName: "",
    areaName: "",
    job1price: "",
    job2price: "",
    job3price: "",//线下的钱
    select: '1',
    pickerHidden: false,
    payWay: "1",
    isIphoneX: app.globalData.isIphoneX,
    nowPrice: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log()
    let url = '/applet/broker/homepage/findBuetails'
    // job 1银牌会员 2金牌会员
    /*
    * explain: "1、通过平台充值599元，可享受12个月会员权益。2、本会员账号仅限本人使用"
      id: "bfe7adee969043aebd9963d39f90e223"
      job: 1
      month_nums: 12
      price: 599
      * */
    app.$http.get(url).then((res) => {
      console.log(res)
      let job1 = res.data.filter(item => { return item.job === 1 })
      let job2 = res.data.filter(item => { return item.job === 2 })

      console.log(job1, 'job1')
      console.log(job2, ' job2')
      this.setData({
        price: res.data.price,
        // month_nums: res.data.month_nums,
        job1price: job1[0].price,
        job2price: job2[0].price,
        job3price: res.data.price - 100,
        month_nums: job1[0].month_nums
      })
    })

    app.$http.get('/location/getAllProvince').then((res) => {//获取所有的省 放入第一个列
      this.setData({
        'multiArray[0]': res.data.map(e => {
          return e.PROVINCE_NAME
        })
      })
    })
    app.$http.post('/location/getAllCityByProvinceCode', { provinceCode: '广东省' }).then((res) => {//获取默认省下面的所有市 放入第二个列
      let a = res.data.map(e => {
        return e.CITY_NAME
      })
      console.log(a, 'aaaaaaaaaaaa')
      this.setData({
        'multiArray[1]': res.data.map(e => {
          return e.CITY_NAME
        })
      })
    })

    let url2 = "/location/getAllAreaByCityCode"
    let data = {
      cityCode: "深圳市"
    }
    app.$http.post(url2, data).then((res) => {//获取第一个市的下面的所有区
      this.setData({
        'multiArray[2]': res.data.map(e => {
          return e.AREA_NAME
        })
      })
    })
  },
  onClickSelect(event) {
    this.setData({
      select: event.currentTarget.dataset.num
    })
  },
  RegionChange: function (e) {
    this.setData({
      region: e.detail.value
    })
  },
  pickerClick() {
    console.log('点击了选择器')
    this.setData({
      pickerHidden: true
    })
  },
  MultiChange(e) {//点击确认的时候
    // console.log(e.detail.value[0])
    // console.log(e.detail.value[1])
    // console.log(e.detail.value[2])
    // console.log(this.data.multiArray[0][e.detail.value[0]])
    // console.log(this.data.multiArray[1][e.detail.value[1]])
    // console.log(this.data.multiArray[2][e.detail.value[2]])

    this.setData({
      multiIndex: e.detail.value,
      provinceName: this.data.multiArray[0][e.detail.value[0]],
      cityName: this.data.multiArray[1][e.detail.value[1]],
      areaName: this.data.multiArray[2][e.detail.value[2]],
    })
  },
  MultiColumnChange(e) {//列发生改变的时候
    let data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0://第一列发生改变的时候
        let data1 = {
          provinceCode: this.data.multiArray[0][e.detail.value]
        }
        let url1 = "/location/getAllCityByProvinceCode"
        app.$http.post(url1, data1).then((res) => {//获取所有的市 放到第二列
          this.setData({
            'multiArray[1]': res.data.map(e => {
              return e.CITY_NAME
            })
          })
        })
        console.log(this.data.multiArray[0][data.multiIndex[0]])//拿到第二列的第一个值

        let data3 = {
          provinceCode: this.data.multiArray[0][data.multiIndex[0]]

        }
        let url3 = "/location/getAllCityByProvinceCode"
        app.$http.post(url3, data3).then((res) => {//获取第一列下的省的第一个市
          console.log(res.data[0].CITY_NAME)
          this.setData({
            firstCityName: res.data[0].CITY_NAME
          })
        }).then(() => {
          let data4 = {
            cityCode: this.data.firstCityName
          };//
          let url4 = "/location/getAllAreaByCityCode"
          app.$http.post(url4, data4).then((result) => {
            this.setData({
              "multiArray[2]": result.data.map(e => {
                return e.AREA_NAME
              })
            })

          })
        })
        data.multiIndex[1] = 0;
        data.multiIndex[2] = 0;
        break;
      case 1:
        console.log(this.data.multiArray[1][e.detail.value])
        let data2 = {
          cityCode: this.data.multiArray[1][e.detail.value]
        }
        let url2 = "/location/getAllAreaByCityCode"
        app.$http.post(url2, data2).then((res) => {
          console.log(res)
          this.setData({
            'multiArray[2]': res.data.map(e => {
              return e.AREA_NAME
            })
          })
        })
        data.multiIndex[2] = 0;
        break;
    }
    this.setData(data);
    console.log(this.data.multiIndex, 'this.data.multiIndex')
  },
  pay(e) {
    console.log(e.currentTarget.dataset.nowprice,'nowprice')
    this.setData({
      nowPrice: e.currentTarget.dataset.nowprice
    })
    if (this.data.payWay === '0') {
      let openid = wx.getStorageSync('openid')
      let token = wx.getStorageSync('token')
      // let data = {
      //   openid:openid,
      //   province: this.data.region[0],
      //   city: this.data.region[1],
      //   district: this.data.region[2]
      // }
      // let url = "/pay/wxPay"
      // app.$http.post(url, data).then((res) => {
      //   console.log(res)
      //   // wx.requestPayment({
      //   //   timeStamp: res.data.timeStamp,
      //   //   nonceStr: res.data.nonceStr,
      //   //   package: 'prepay_id=' + res.data.package,
      //   //   signType: 'MD5',
      //   //   paySign: res.data.paySign,
      //   //   success(res) {
      //   //     let newDate = util.formatTime2(new Date())
      //   //     wx.setStorageSync('newDate', newDate)
      //   //     wx.switchTab({
      //   //       url: '../index/index'
      //   //     })
      //   //   },
      //   //   fail(res) {

      //   //   }
      //   // })
      // })
      if (!(this.data.provinceName && this.data.cityName && this.data.areaName)) {
        // console.log('请选择服务地区后点击确定按钮')
        wx.showToast({
          title: '请选择服务地区'
        })
        return false
      }
      wx.request({
        url: 'https://applet.fbfcn.com/pay/wxPay', //仅为示例，并非真实的接口地址
        //url: 'http://tunnel.fbfcn.com/pay/wxPay', //仅为示例，并非真实的接口地址
        data: {
          openid: openid,
          province: this.data.provinceName,
          city: this.data.cityName,
          district: this.data.areaName,
          job: this.data.select
        },
        header: {
          'content-type': 'application/json', // 默认值
          'token': token
        },
        success(res) {
          console.log(res)
          wx.requestPayment({
            timeStamp: res.data.timeStamp,
            nonceStr: res.data.nonceStr,
            package: 'prepay_id=' + res.data.package,
            signType: 'MD5',
            paySign: res.data.paySign,
            success(res) {
              console.log(res)
              wx.navigateTo({
                url: '../login/login'
              })
              //支付成功之后重新登录
              wx.setStorageSync("token", null)
              wx.setStorageSync("login", null)
              wx.setStorageSync("userInfor", null)
              wx.setStorageSync("brokerRegionInfo", null)
              wx.setStorageSync("openid", null)
            },
            fail(res) {

            }
          })
        }
      })
    } else if (this.data.payWay === '1') {
      this.showModal()

    } else if (this.data.payWay === '2') {
      console.log(
        'alert2'
      )
      this.showModal2()
    }
  },
  ////新增支付方式

  radioCheacked(e) {
    console.log(e.currentTarget.dataset.id)
    if (e.currentTarget.dataset.id === '1') {
      this.setData({
        payWay: '1'
      })
    } else if (e.currentTarget.dataset.id === '2') {
      this.setData({
        payWay: '2'
      })
    } else if (e.currentTarget.dataset.id === '0') {
      this.setData({
        payWay: '0'
      })
    }
  },
  showModal(e) {//展示图片
    this.setData({
      modalName: 'Image'
    })
  },
  showModal2(e) {//展示银行卡
    this.setData({
      modalName: 'Modal'
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  toXieyi() {
    wx.navigateTo({
      url: "/pages/rule/rule"
    })
  }
})
