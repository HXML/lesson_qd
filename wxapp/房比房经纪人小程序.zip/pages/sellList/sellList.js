// pages/sellList/sellList.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sendData: {
      pageNumber: 1,
      pageSize: 6,
      type: 3,    //房源类型（1为普通房源，2为优质房源
      model: "",//户型1-5 直接传数字，不限传"" 5室以上就传5室以上
      price: "",//-
      decorate_status: "",//装修情况直接用字符串填充(豪装，精装，简装，毛坯)
      province: "",//省级行政区
      city: "",//市级行政区
      district: "",//区
      street: "",//街道
    },
    houseList: [],
    //下拉加载
    msg: "加载中...",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getSecondhandList(3)
  },
  getSecondhandList(type) {
    let url = "/applet/broker/housingrec/pesonhouse/findPageEPersonHouse"
    this.setData({
      'sendData.type': type
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      this.setData({
        houseList: res.data.list.map(e => {
          return {
            address: e.address,
            area: e.area,
            city: e.city,
            decorate_status: e.decorate_status,
            district: e.district,
            id: e.id,
            mobile: e.mobile,
            name: e.name,
            position: e.position,
            province: e.province,
            sell_house_price: e.sell_house_price,
            street: e.street,
            type_balcony_num: e.type_balcony_num,//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
            type_parlor_num: e.type_parlor_num,//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
            type_room_num: e.type_room_num,//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
            type_toilet_num: e.type_toilet_num,//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
          }
        })
      })
    })
  },
  callHim(e) {
    let login = wx.getStorageSync('login')
    if (!login) {
      this.setData({
        showPop: true
      })
    } else {
      console.log(e.currentTarget.dataset.mobile)
      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.mobile //仅为示例，并非真实的电话号码
      })
    }
  },
  getMoreList(type) {
    console.log('获取二手房信息')
    let url = "/applet/broker/housingrec/pesonhouse/findPageEPersonHouse"
    this.setData({
      'sendData.type': type,
      'sendData.pageNumber': this.data.sendData.pageNumber + 1
    })
    let data = this.data.sendData
    app.$http.post(url, data).then((res) => {
      console.log(res)
      let newArr = res.data.list.map(e => {
        return {
          address: e.address,
          area: e.area,
          city: e.city,
          decorate_status: e.decorate_status,
          district: e.district,
          id: e.id,
          mobile: e.mobile,
          name: e.name,
          position: e.position,
          province: e.province,
          sell_house_price: e.sell_house_price,
          street: e.street,
          type_balcony_num: e.type_balcony_num,//房屋户型 阳台数（0为0阳台，1为1阳台，2为2阳台，3为3阳台及以上）
          type_parlor_num: e.type_parlor_num,//房屋户型 客厅数 （0为0厅，1为1厅，2为2厅，3为3厅，4为4厅及以上）
          type_room_num: e.type_room_num,//房屋户型 房间数（1为1居室，2为2居室，3为3居室，4为4居室，5为5室及以上）
          type_toilet_num: e.type_toilet_num,//房屋户型 卫生间数（0为0卫，1为1卫，2为2卫，3为3卫，4为4卫，5为5卫及以上）
        }
      })
      if (res.data.totalRow > this.data.houseList.length) {
        this.setData({
          houseList: [...this.data.houseList, ...newArr]
        })
      } else {
        this.setData({
          msg: "加载完成"
        })
        return false
      }

    })
  },
  toHouseDetail(e) {
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: "/pages/secondHandHouse/secondHandHouse?id=" + e.currentTarget.dataset.id
    })
  },
  onReachBottom: function () {
    if (this.data.msg === "加载中...") {
      this.getMoreList(3)
    } else {
      return false
    }
  },
  onPullDownRefresh() {//刷新
    wx.showToast({
      title: '加载中....',
      icon: 'loading'
    })
    let that = this
    //模拟加载
    setTimeout(function () {
      //点击刷新
      that.setData({
        'sendData.pageNumber': 1,
        ScrollTop: 0,
        msg: '加载中...'
      })
      // console.log(that.data.title)
      // that.data.TabCur == 1 ? that.getList(2) : that.getList(1)
      that.getSecondhandList(3)
      wx.hideLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  showLogin() {
    this.setData({ showPop: true });
  },
  //弹窗时间
  getPhoneNumber() {
    this.setData({ showPop: false });
    wx.navigateTo({
      url: "../login/login"
    })
  },
  onClose() {
    this.setData({ showPop: false });
  },
})