//app.js
import $http from './utils/http.js'
var QQMapWX = require('./utils/lib/qqmap-wx-jssdk.js');
var $qqmapsdk;
$qqmapsdk = new QQMapWX({
  key: 'WDZBZ-IYTL5-WPFIZ-QTALF-5OYHH-G2BAQ'
  // key: 'YQCBZ-J4OKQ-XEZ5I-GG5HQ-XZF5F-GUFS4'
});
App({
  $qqmapsdk,
  $http,
  globalData: {
    isIphoneX: null,
    userInfo: null,
    windowHeight: wx.getSystemInfoSync()['windowHeight'],
    statusBarHeight: wx.getSystemInfoSync()['statusBarHeight']
  },
  onLaunch: function () {
    // 获取系统状态栏信息
    wx.getSystemInfo({
      success: e => {
        console.log(e)
        this.globalData.StatusBar = e.statusBarHeight;
        let capsule = wx.getMenuButtonBoundingClientRect();
        if (capsule) {
          this.globalData.Custom = capsule;
          this.globalData.CustomBar = capsule.bottom + capsule.top - e.statusBarHeight;
        } else {
          this.globalData.CustomBar = e.statusBarHeight + 50;
        }
        let model = e.model.substring(0, e.model.indexOf("X")) + "X"
        if (model == 'iPhone X') {
          this.globalData.isIphoneX = true
        }
      }
    })
  },

  // ///动画
  // //渐入，渐出实现 
  // show: function (that, param, opacity) {
  //   var animation = wx.createAnimation({
  //     //持续时间800ms
  //     duration: 800,
  //     timingFunction: 'ease',
  //   });
  //   //var animation = this.animation
  //   animation.opacity(opacity).step()
  //   //将param转换为key
  //   var json = '{"' + param + '":""}'
  //   json = JSON.parse(json);
  //   json[param] = animation.export()
  //   //设置动画
  //   that.setData(json)
  // },

  // //滑动渐入渐出
  // slideupshow: function (that, param, px, opacity) {
  //   var animation = wx.createAnimation({
  //     duration: 800,
  //     timingFunction: 'ease',
  //   });
  //   animation.translateY(px).opacity(opacity).step()
  //   //将param转换为key
  //   var json = '{"' + param + '":""}'
  //   json = JSON.parse(json);
  //   json[param] = animation.export()
  //   //设置动画
  //   that.setData(json)
  // },

  // //向右滑动渐入渐出
  // sliderightshow: function (that, param, px, opacity) {
  //   var animation = wx.createAnimation({
  //     duration: 800,
  //     timingFunction: 'ease',
  //   });
  //   animation.translateX(px).opacity(opacity).step()
  //   //将param转换为key
  //   var json = '{"' + param + '":""}'
  //   json = JSON.parse(json);
  //   json[param] = animation.export()
  //   //设置动画
  //   that.setData(json)
  // }
})