import { baseUrl } from './config.js'

/**
 * url 请求地址
 * data 请求参数
 * loading 可选项 是否需要loading,默认为true
 */

const get = (url, data, loading) => {
  let token = wx.getStorageSync('token');
  url = baseUrl + url;
  return new Promise((resolve, reject) => {
    if (loading) {
      wx.showLoading({
        title: '玩命加载中。。。。',
      })
    }
    wx.request({
      url,
      method: 'get',
      data,
      header: {
        'token': token||''
      },
      success: (res) => {
        if (res.data.code === 200) {
          resolve(res.data);
        } else {
          resolve(res.data);
          console.log(res.data.msg);
        }
      }, fail: (err) => {
        // 弹窗轻提示用户错误的信息
        console.log('请求失败信息', err);
      }, complete: () => {
        wx.hideLoading();
      }
    })
  })
}

const post = (url, data, loading) => {
  let token = wx.getStorageSync('token');
  url = baseUrl + url;
  return new Promise((resolve, reject) => {
    if (loading) {
    wx.showLoading({
      title: '加载中...',
    })
    }
    wx.request({
      url,
      method: 'post',
      data,
      header: {
        'token': token||''
      },
      success: (res) => {
        if (res.data.code === 200) {
          resolve(res.data);
        } else {
          resolve(res.data);
          console.log(res.data.msg);
        }
      }, fail: (err) => {
        console.log('请求失败信息', err);
      }, complete: () => {
        let s=setTimeout(function () {
          wx.hideLoading();
          clearTimeout(s)
        },1000)
      }
    })
  })
}

export default {
  get,
  post
}
