// 判断环境
let env = 'pro';
let baseUrl = ''
if (env === 'dev') {
  baseUrl = 'http://192.168.0.100:8081';//何康
} else if (env === 'test') {
  baseUrl = 'https://test.fbfcn.com';
} else if (env === 'pro') {
  baseUrl = 'https://applet.fbfcn.com';
}
export {
  baseUrl
}
